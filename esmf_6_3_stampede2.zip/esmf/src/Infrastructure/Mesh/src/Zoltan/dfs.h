/*****************************************************************************
 * CVS File Information :
 *    $RCSfile: dfs.h,v $
 *    $Author: dneckels $
 *    $Date: 2007/11/28 16:13:47 $
 *    Revision: 1.11 $
 ****************************************************************************/

#ifndef __DFS_H
#define __DFS_H

#include "dfs_const.h"

#ifdef __cplusplus
/* if C++, define the rest of this header file as extern C */
extern "C" {
#endif


#ifdef __cplusplus
} /* closing bracket for extern "C" */
#endif

#endif
