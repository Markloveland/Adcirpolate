LogKind
=======

This flag is used to specify how much logging should be done.

Values are:

    MULTI = 2
        Use multiple log files -- one per PET.
    NONE = 3
        Do not issue messages to a log file.
