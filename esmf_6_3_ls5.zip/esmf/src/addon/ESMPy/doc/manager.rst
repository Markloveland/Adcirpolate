.. toctree::
   :maxdepth: 2

.. _manager:

Manager
=======

.. autoclass:: ESMF.Manager
  :members:
