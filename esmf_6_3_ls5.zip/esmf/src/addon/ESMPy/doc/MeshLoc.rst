MeshLoc
=======

The Mesh location used to hold Field data.

Values are:

    NODE = 1
        The nodes of the Mesh
    ELEMENT = 2
        The elements of the Mesh
