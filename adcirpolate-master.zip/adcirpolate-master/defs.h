!++++++++++++++++++++++++++++++++++!
! We put all the definitions here: !
!++++++++++++++++++++++++++++++++++!

#define DEBUG_MODE
!#define DEBUG_MANIAC

!++++++++++++++++++++++++++++!
! End of definitions section !
!++++++++++++++++++++++++++++!

